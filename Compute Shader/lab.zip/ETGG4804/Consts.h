#pragma once

#define WIDTH 256
#define HEIGHT 256
#define PI 3.14159265358979323;
#define INFINITY std::numeric_limits<float>::infinity()