#include <iostream>
#include "Wave.h"
#include "Stopwatch.h"
#include "ymm.h"
#include "xmm.h"
#include <immintrin.h>

using namespace std;

int main(int argc, char* argv[])
{
    string filename = argv[1];

    Wave inwave(filename);
    if (inwave.format.format != 1 || inwave.format.numChannels != 1 || inwave.format.bitsPerSample != 8) {
        cout << "Not an 8 bit mono wave\n";
        return 1;
    }

    int nf = inwave.numFrames;
    Wave outwave(inwave.format, inwave.numFrames/2);
    int32_t* p = (int32_t*)inwave.data();
    int32_t* op = (int32_t*)outwave.data();
    ymmi8 mask(14, 12, 10, 8, 6, 4, 2, 0, 15, 13, 11, 9, 7, 5, 3, 1, 14, 12, 10, 8, 6, 4, 2, 0, 15, 13, 11, 9, 7, 5, 3, 1);
    ymmi32 permute_mask(0,1,4,5,-1,-1,-1,-1);
    Stopwatch swatch;
    swatch.start();
    for (unsigned i = 0; i < nf; i+=32, p+=32, op+=16) {
        ymmi32 out(p);
        //auto high = _mm256_permute2f128_si256(out, out, 0x81);
        ymmi32 shuffled = out.shuffle(mask);
        ymmi32 permuted = _mm256_permute4x64_epi64(shuffled, 0b11011000);

        //ymmi32 fin = _mm256_permutevar8x32_epi32(shuf, ymmi32(0,2,4,6,0,0,0,0));
        permuted.toxmm().store(op);
    }
    swatch.stop();
    std::cout << swatch.elapsed_us() << " elapsed us" << std::endl;
    outwave.write("out.wav");

    return 0;
}
